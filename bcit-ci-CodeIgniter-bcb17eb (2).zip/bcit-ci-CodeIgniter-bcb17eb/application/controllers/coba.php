<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class coba extends CI_Controller {

	
	public function index()
	{
		$data['query'] = $this->db->get('catatan_perjalanan')-result();

        $this->load->view('view_data',$data);

	}
}
