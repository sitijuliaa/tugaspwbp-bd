<!DOCTYPE html>
<html>
<head>
	<title>Document</title>
</head>
<body>
    <h1> ini data </h1>
    <table border="1">
    <tr>
        <tr>ID soal</tr>
</tr>
<?php foreach($query as $query){?> 
    <tr>
    <tb><?=$query->idcp ?></td>
</tr> 
<?php}?>
        
</table>}


</body>
</html>
