<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>
<h1 class=""styles="background; color:white">login</h1>
<?php echo $jurusan;?>
<?php echo $jurusan;?>


</body>
</html>